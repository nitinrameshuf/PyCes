import cv2
import torch
import time
import numpy as np
from facenet_pytorch import MTCNN
from glob import glob
from PIL import Image, ImageDraw
import os

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
print('Running on device: {}'.format(device))

class FaceDetector(object):
    """
    Face detector class
    """

    def __init__(self, mtcnn):
        self.mtcnn = mtcnn
        self.outputFolder = './results'
        self.trainingFolder = f'{self.outputFolder}/train'
        self.validationFolder = f'{self.outputFolder}/validate'
        self.frame_tracked = []

    def _cropPhotos(self):
        
        _errorCount = 0
        _files = sorted(glob(self.trainingFolder + '/*.jpg'))
        for i, _file in enumerate (_files):
            frame = cv2.imread(_file)
            try:
                boxes, probs = self.mtcnn.detect(frame)
                coors = boxes[0].tolist()
                newImage = frame[int(coors[1]):int(coors[3]), int(coors[0]):int(coors[2])]
                cv2.imwrite( f'{self.trainingFolder}/extracted_image_{i}.jpg',newImage,)
            except Exception as e:
                _errorCount += 1

        print(f'Success rate : {_errorCount/len(_files):.3f}')


    def takeInitialPhotos(self):
        """
        Take images of the room for 10 seconds , extract faces as training sources
        """
        cap = cv2.VideoCapture(0)
        _startTime = time.time()
        _count = 0
        _currentTime = time.time()
        print(self.trainingFolder)
        while(time.time()- _startTime < 15):
            if(time.time() - _currentTime > 0.2):
                ret, frame = cap.read()
                if not ret:
                    continue
                else:
                    cv2.imwrite(self.trainingFolder +f'/{_count}.jpg', frame)
                    _count += 1
                _currentTime = time.time()
            else:
                continue

        cap.release()
        print(f'Fetched {_count} images for training.')

        # crop the face of images and saved to the file

        # assign some of images to validation




    def _draw(self, frame, boxes, probs, landmarks):
        """
        Draw landmarks and boxes for each face detected
        """
        try:
            for box, prob, ld in zip(boxes, probs, landmarks):
                # Draw rectangle on frame
                cv2.rectangle(frame,
                              (int(box[0]), int(box[1])),
                              (int(box[2]), int(box[3])),
                              (0, 0, 255),
                              2)

                # Show probability
                cv2.putText(frame, str(
                    prob), (int(box[2]), int(box[3])), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2, cv2.LINE_AA)

                ld = np.rint(ld).astype(int)
                # Draw landmarks
                cv2.circle(frame, tuple(ld[0]), 5, (0, 0, 255), -1)
                cv2.circle(frame, tuple(ld[1]), 5, (0, 0, 255), -1)
                cv2.circle(frame, tuple(ld[2]), 5, (0, 0, 255), -1)
                cv2.circle(frame, tuple(ld[3]), 5, (0, 0, 255), -1)
                cv2.circle(frame, tuple(ld[4]), 5, (0, 0, 255), -1)

        except Exception as e:
            print('error to draw: ', e)

        return frame

    def run(self):
        """
            Run the FaceDetector and draw landmarks and boxes around detected faces
        """
        cap = cv2.VideoCapture(0)

        while True:
            ret, frame = cap.read()
            try:
                # detect face box, probability and landmarks
                boxes, probs, landmarks = self.mtcnn.detect(frame, landmarks=True)
                # draw on frame
                self._draw(frame, boxes, probs, landmarks)

            except:
                pass

            # Show the frame
            cv2.imshow('Face Detection', frame)

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        cap.release()
        cv2.destroyAllWindows()
        
        
# Run the app
mtcnn = MTCNN(select_largest=True, device=device)
fcd = FaceDetector(mtcnn)
# fcd.run()
fcd._cropPhotos()