from amcrest import AmcrestCamera
import time
import asyncio
from asyncio.exceptions import TimeoutError


## Define Camera Object
camera = AmcrestCamera(host='192.168.1.108', port='80', user='admin', password='Wzdhxhngzy199512!', verbose=True, ssl_verify=False).camera
# TODO: save configuration file into .conf

## take snapshot
# camera.snapshot(path_file='./testImages/test2.jpeg')

## PTZ control of the camera

# Move UP

# camera.move_left(start=True)
# time.sleep(0.5)
# camera.move_left(start=False)
# Move Down

# Move to Location

# Auto PTZ movement
# camera.ptz_auto_movement() # PtzAutoMovement config file requested

# async def main():
#     task = asyncio.create_task(
#         camera.async_move_right(start=True)
#     )

#     MAX_TIMEOUT = 0.5
#     try:
#         await asyncio.wait_for(task, timeout=MAX_TIMEOUT)
#     except TimeoutError:
#         print('The task was cancelled due to a timeout')
#     camera.async_move_right(start=False)
# asyncio.run(main())


async def setUpAction(actionType: str, actionTime: int = 500 , **kwargs):
    """_summary_

    Args:
        actionType (str): _description_
        actionTime (int, optional): _description_. Defaults to 500.
        kwargs:
            if actionType == 'Point', camera will move to specific location by coordinators:
            kwargs contains 
                [startpoint_x: int,
                startpoint_y: int,
                endpoint_x: int,
                endpoint_y: int,]
    """

    if(actionType == 'Up'):
        await camera.async_move_up(start=True, **kwargs)
        await asyncio.sleep(actionTime / 1000)
        await camera.async_move_up(start=False)
    elif(actionType == 'Down'):
        await camera.async_move_down(start=True, **kwargs)
        await asyncio.sleep(actionTime / 1000)
        await camera.async_move_down(start=False)
    elif(actionType == 'Left'):
        await camera.async_move_left(start=True, **kwargs)
        await asyncio.sleep(actionTime / 1000)
        await camera.async_move_left(start=False)
    elif(actionType == 'Right'):
        await camera.async_move_right(start=True, **kwargs)
        await asyncio.sleep(actionTime / 1000)
        await camera.async_move_right(start=False)
    elif(actionType == 'LeftUp'):
        await camera.async_move_left_up(start=True, **kwargs)
        await asyncio.sleep(actionTime / 1000)
        await camera.async_move_left_up(start=False)
    elif(actionType == 'LeftDown'):
        await camera.async_move_left_down(start=True, **kwargs)
        await asyncio.sleep(actionTime / 1000)
        await camera.async_move_left_down(start=False)
    elif(actionType == 'RightUp'):
        await camera.async_move_right_up(start=True, **kwargs)
        await asyncio.sleep(actionTime / 1000)
        await camera.async_move_right_up(start=False)
    elif(actionType == 'RightDown'):
        await camera.async_move_right_down(start=True, **kwargs)
        await asyncio.sleep(actionTime / 1000)
        await camera.async_move_right_down(start=False)
    elif(actionType == 'Initial'):
        actionTime = 10000
        await camera.async_move_left_down(start=True, vertical_speed=8, horizontal_speed=8)
        await asyncio.sleep(actionTime / 1000)
        await camera.async_move_left_down(start=False)
    elif(actionType == 'Private'):
        actionTime = 5000
        await camera.async_move_down(start=True, vertical_speed=8)
        await asyncio.sleep(actionTime / 1000)
        await camera.async_move_down(start=False)
    elif(actionType == 'Position'):
        # vertical_angle required
        # horizontal_angle required
        await camera.async_position_abs(start=True, **kwargs)
    else:
        print('Action is not defined.')

## initial setting

# asyncio.run(setUpAction('Position', vertical_angle = 180, horizontal_angle= 0))
# asyncio.run(setUpAction(actionType='Intial'))
# asyncio.run(setUpAction(actionType='Right', actionTime=50, horizontal_speed = 8))
# asyncio.run(setUpAction(actionType='Down', actionTime=50, vertical_speed = 8))
# asyncio.run(setUpAction(actionType='Up', actionTime=20, vertical_speed = 8))
