#############################
#Light weight MTCNN detector
#IC3 laboratory Cart
#############################
import cv2
import sys
from mtcnn.mtcnn import MTCNN

def draw_bounding_box(frame, location):
    if len(location) > 0:
        for face in location:
            x, y, width, height = face['box']
            x2, y2 = x + width, y + height
            cv2.rectangle(frame, (x, y), (x2, y2), (0, 0, 255), 4)

# Detect Image:
def detect_image(path):
    detector = MTCNN()
    img=cv2.imread(path)
    location = detector.detect_faces(img)
    draw_bounding_box(img,location)
    #Update the path below
    cv2.imwrite("files/path_to_file.jpg",img)

# Detect Video:
def detect_video(path):
    detector = MTCNN()
    video = cv2.VideoCapture("files/path_to_file.mp4")
    #Ensure there is no lock on the camera
    if (video.isOpened() == False):
        print("Error reading video file")
    frame_width = int(video.get(3))
    frame_height = int(video.get(4))
    size = (frame_width, frame_height)
    result = cv2.VideoWriter('files/path_to_file.mp4',cv2.VideoWriter_fourcc(*'MJPG'),29, size)
    frame_num=0
    while (True):
        ret, frame = video.read()
        frame_num += 1
        print(frame_num)
        if ret == True:
            location = detector.detect_faces(frame)
            draw_bounding_box(frame, location)
            result.write(frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        else:
            #Processing Completed
            break
    video.release()
    result.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    if(len(sys.argv)==1):
        #Running an example from the photo in the "files directory"
        path = 'files/example_photo.jpg'
        detect_image(path)
        print("Output in the results folder")
    elif(len(sys.argv == 3)):
        mode = sys.argv[1]
        path = sys.argv[2]
        if(mode == 1):
            detect_image(path)
        else:
            detect_video(path)
    else:
        print("Argument 1: Mode(1:Image or 2:Video) and Argument 2: Path to file")