#############################
#Camera Control Unit 
#ArduCam PTK Kit
#IC3 laboratory Cart
#############################