#############################
#Camera Functions Unit
#IC3 laboratory Cart
#############################
import time, libcamera, datetime
from picamera2 import Picamera2, Preview
from picamera2.encoders import H264Encoder

#Initialize the camera
picam = Picamera2()

def capture_image(width = 1600, height = 1200, flip = False):
    config = picam.create_preview_configuration(main={"size": (width, height)})
    
    if(flip == True):
        config["transform"] = libcamera.Transform(hflip=1, vflip=1)
        
    picam.configure(config)
    
    #Preview screen
    picam.start_preview(Preview.QTGL)
    
    output_file_path = "/home/users/Desktop/" + str(datetime.datetime.now().strftime("%Y%m%d-%H%M%S")) +".jpg"
    
    picam.start()
    time.sleep(1)
    #For checking error conditions like running out of memory, use below wait function.
    #camera.wait_recording(60)
    picam.capture_file(output_file_path)
    picam.close()

def capture_video(length = 10):
    #Using inbuilt method to create short 10 second videos.
    video_config = picam.create_video_configuration()
    picam.configure(video_config)
    
    encoder = H264Encoder(10000000)
    
    picam.start_recording(encoder, 'test.h264')
    time.sleep(length)
    picam.stop_recording()
    
if __name__ == "__main__":
    capture_image(width = 1280, height = 720)
    capture_video()