'''
	Python Patterns Rulepack
'''
import os,re,remc

PATTERNS_DB = {
#Patterns
"Pattern_TimeBomb":{"base_rating":8,"desc":"Contains a time finding potentially acting in concert with other suspicious functionality.","regex":""},
"Pattern_Trojan":{"base_rating":8,"desc":"Contains potentially suspicious functionality that is obfuscated.","regex":""},
"Pattern_Backdoor":{"base_rating":8,"desc":"Contains functionality to open endpoints potentially in concert with other suspicious functionality.","regex":""},
"Pattern_Rootkit":{"base_rating":8,"desc":"Contains native functionality potentially in concert with other suspicious functionality.","regex":""},

}

#Add keys as name param for all findings.
for fk in PATTERNS_DB.keys():
	PATTERNS_DB[fk]["finding_name"] = fk

	

def detect_pattern(tst_lst,findings_db,findings_db2,pattern_entry,sec_component,bo=True):
	fc = 0
	for tb in tst_lst:
		rfl = []
		srcpool = str(findings_db[tb]['import_list'])+" "+findings_db[tb]['srcfile']
		for fk in findings_db.keys():
			if(findings_db[fk]['srcfile'] in srcpool):
				rfl.append(fk)
		for rf in rfl:
			if(bo == False):
				if(not sec_component in findings_db[rf]['finding_name']):
					tmp_etry = findings_db[tb]
					tmp_etry['finding_name'] = pattern_entry['finding_name']
					sec_loc = " Second_Loc: %s:%d" % (findings_db[rf]['srcfile'],findings_db[rf]["finding_lineno"])
					tmp_etry['desc'] = pattern_entry['desc']+sec_loc
					tmp_etry["base_rating"] = pattern_entry["base_rating"]	
					nhash = findings_db[tb]['srcfile']+" "+findings_db[rf]['srcfile']
					findings_db2[nhash] = tmp_etry
					fc+=1
			else:
				if(sec_component in findings_db[rf]['finding_name']):
					tmp_etry = findings_db[tb]
					tmp_etry['finding_name'] = pattern_entry['finding_name']
					sec_loc = " Second_Loc: %s:%d" % (findings_db[rf]['srcfile'],findings_db[rf]["finding_lineno"])
					tmp_etry['desc'] = pattern_entry['desc']+sec_loc
					tmp_etry["base_rating"] = pattern_entry["base_rating"]	
					nhash = findings_db[tb]['srcfile']+" "+findings_db[rf]['srcfile']
					findings_db2[nhash] = tmp_etry
					fc+=1
	#print("%s Findings: %d" % (pattern_entry['finding_name'],fc))
	return findings_db2
	
'''
Patterns
	Timebomb = time + !time
	Trojan = stealth + !stealth
	Backdoor = comm + stealth
	Rootkit = LL + Stealth
'''
	
def run_rules(findings_db):
	tb_tst = []
	tr_tst = []
	rk_tst = []
	bk_tst = []
	
	findings_db2 = findings_db
	for mf in findings_db.keys():
		if("Time" in findings_db[mf]["finding_name"]):
			tb_tst.append(mf)
		if("Communication_" in findings_db[mf]["finding_name"]):
			bk_tst.append(mf)
		if("Stealth_" in findings_db[mf]["finding_name"]):
			tr_tst.append(mf)
		if("LL_" in findings_db[mf]["finding_name"]):
			rk_tst.append(mf)

	#Time Detection
	findings_db2 = detect_pattern(tb_tst,findings_db,findings_db2,PATTERNS_DB["Pattern_TimeBomb"],"Time",False)
	#Trojan Detection
	findings_db2 = detect_pattern(tb_tst,findings_db,findings_db2,PATTERNS_DB["Pattern_Trojan"],"Stealth",False)
	#Backdoor Detection
	findings_db2 = detect_pattern(tb_tst,findings_db,findings_db2,PATTERNS_DB["Pattern_Backdoor"],"Stealth",True)
	#Rootkit Detection
	findings_db2 = detect_pattern(tb_tst,findings_db,findings_db2,PATTERNS_DB["Pattern_Rootkit"],"Stealth",True)
	


	return findings_db2
	

