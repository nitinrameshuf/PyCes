'''
	PythonMCD Runtime
'''

#General Imports
import os,sys,re,tempfile,datetime,subprocess,time,uuid,pickle

#Our Imports
import findings,patterns,uncompyle6,post_proc
TOOL_VER = "0.01"
MODULE_DB = {}

'''
DBG_CACHING makes a pickle file of the disasm/decomp results to greatly
speed up rescans, but it is insecure to write data to a file.
Exercise caution when enabling this option and always clear
your cache files.
'''
DBG_CACHING = False
if os.name == 'nt':
	CDAS_PATH = "pycdas.exe"
	CDC_PATH = "pycdc.exe"
else:
	#TODO - ACTUALLY COMPILE FOR LINUX!!!
	CDAS_PATH = "./pycdas"
	CDC_PATH = "./pycdc"	
DEPENDENCY_LIST = {}
FINDINGS_DB = {}
PATTERNS_DB = {}
SFOOD_PATH = "sfood"
#REPORT_PATH = "reports"

#Set up pymcd_root as a default python path (for using custom python roots).
def env_setup():
	newspath = []
	cpath = os.getcwd()
	cpath = os.path.join(cpath)
	#Add our paths with local override.
	newspath.append(sys.path[0])
	newspath.append(cpath)
	newspath.append(sys.path[1:])
	sys.path = newspath

def escape_xml(ins):
	ins = ins.replace("&","&amp;")
	ins = ins.replace("'","&apos;")
	ins = ins.replace("<","&lt;")
	ins = ins.replace(">","&gt;")
	ins = ins.replace("\"","&quot;")
	return ins

def gen_fvdl_report(out_fpr_directory):
	vulns_uuid = uuid.uuid1(int(time.time()))
	
	#Boilerplate FVDL Stuff.
	fvdl_file = "<?xml version=\"1.0\"?>"
	'''
	

	'''
	fvdl_file += "<FVDL xmlns=\"xmlns://www.fortifysoftware.com/schema/fvdl\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" version=\"1.9\" xsi:type=\"FVDL\"><CreatedTS date=\"2014-05-15\" time=\"14:25:33\" /><Build/>"
	fvdl_file+="<Vulnerabilities>"
	for nk in FINDINGS_DB.keys():
		fndg = FINDINGS_DB[nk]
		
		
			
		fvdl_file+="<Vulnerability xmlns=\"xmlns://www.fortifysoftware.com/schema/fvdl\">"			
		fvdl_file+="<ClassInfo>"
		fvdl_file+="<ClassID>com.cigital.mcd</ClassID>"
		fvdl_file+="<Kingdom>MCD</Kingdom>"
		fvdl_file+="<Type>MCD Element</Type>"
		fvdl_file+="<Subtype>%s</Subtype>" % escape_xml(fndg["finding_name"])
		fvdl_file+="<AnalyzerName>pyMCD</AnalyzerName>"
		fvdl_file+="</ClassInfo>"
			
		fvdl_file+= "<InstanceInfo>"
		fvdl_file+= "<InstanceID>%s</InstanceID>" % uuid.uuid1(int(time.time()))
		fvdl_file+= "<Confidence>5.0</Confidence>"
		fvdl_file+= "</InstanceInfo>"
			
		fvdl_file+= "<AnalysisInfo>"
		fvdl_file+= "<Unified>"
		fvdl_file+= "<Trace>"
		fvdl_file+= "<Primary>"
		fvdl_file+= "<Entry>"
		fvdl_file+= "<Node>"
		fvdl_file+= "<SourceLocation colEnd='0' colStart='0' line='%s' lineEnd='' path=\"%s\"/>" % (str(fndg["finding_lineno"]),fndg["srcfile"].replace("\\","//"))
		fvdl_file+= "<Action>%s  :: %s</Action>" % (escape_xml(fndg["desc"]),escape_xml(fndg["finding_snippet"]))
		fvdl_file+= "</Node>"
		fvdl_file+= "</Entry>"
		fvdl_file+= "</Primary>"
		fvdl_file+= "</Trace>"
		fvdl_file+= "</Unified>"
		fvdl_file+= "</AnalysisInfo>"	
		fvdl_file+="</Vulnerability>"

	
	#End of File
	fvdl_file += "</Vulnerabilities></FVDL>"
	outfname = os.path.join(out_fpr_directory,time.strftime("report_%Y%m%d%H%M%S.fvdl"))
	g = open(outfname,"wb")
	g.write(fvdl_file)
	g.close()
	return outfname
	
def gen_html_report(rating_cutoff):
	report_db = {}
	#TODO - Rate all findings and eliminate duplicates by matching on the srcpath+linenumber.
	frep = open(os.path.join(REPORT_PATH,time.strftime("Findings_Report.htm")),"wb")
#	frep.write("<h1>Report %s</h1><br/><br/>" % datetime.datetime.now())
	frep.write("<form style='background-color:NavajoWhite;font-size:20px'>")
	frep.write("<table border='2'>")
	frep.write("<tr>")
	frep.write("<form bg-color='orange' wrap='hard'/>")
	frep.write("<th><b>Finding Name</b></th>")
	frep.write("<th>Finding Description</th>")
	frep.write("<th>Finding Snippet</th>")
	frep.write("<th>Srcfile:Lineno.</th>")
	frep.write("</tr>")
	
	for nk in FINDINGS_DB.keys():
		fndg = FINDINGS_DB[nk]
		
		frep.write("<tr>")
		frep.write("<b><td>%s</td>" % fndg["finding_name"])
		frep.write("<td>%s</td>" % fndg["desc"])
		frep.write("<td>%s</td>" % fndg["finding_snippet"])
		frep.write("<td><a href='%s'/>%s</a>:%d</td>" % (fndg["srcfile"],fndg["srcfile"],fndg["finding_lineno"]))
		frep.write("</tr>")
			
	frep.write("</table>")
	frep.close()

def proc_findingsdb():
	global FINDINGS_DB
	FINDINGS_DB = patterns.run_rules(FINDINGS_DB)
	
	

		
def proc_moduledb():
	
	for mk in MODULE_DB.keys():
		#We don't want to scan anything in our 'known-good' python install...
		if(os.path.join(os.getcwd(),"Lib") in mk):
			continue
		if(sys.argv[3] == "Normal"):	
			FINDINGS_DB.update(findings.run_rules(mk,MODULE_DB[mk]))

		elif(sys.argv[3] == "High"):	
		 	FINDINGS_DB.update(findings.run_rules2(mk,MODULE_DB[mk]))
		
		# run_rules	is	general	with	all	rule-sets,	run_rules_1	onwards	is	for	specific	rulesets
		#if(sys.argv[3]	==	"All"):	
		#	FINDINGS_DB.update(findings.run_rules(mk,MODULE_DB[mk]))

		# elif(sys.argv[3]	==	"CherryPy"):	
		# 	FINDINGS_DB.update(findings.run_rules2(mk,MODULE_DB[mk]))

		# elif(sys.argv[3]	==	"Django"):	
		# 	FINDINGS_DB.update(findings.run_rules3(mk,MODULE_DB[mk]))
		
		# elif(sys.argv[3]	==	"Flask"):	
		# 	FINDINGS_DB.update(findings.run_rules4(mk,MODULE_DB[mk]))		
			
		# elif(sys.argv[3]	==	"Web2Py"):	
		# 	FINDINGS_DB.update(findings.run_rules5(mk,MODULE_DB[mk]))		
		
		else:
			print	"Your	rule	set	input	is	invalid.Running	all	the	rules."
# 			FINDINGS_DB.update(findings.run_rules(mk,MODULE_DB[mk]))	
				
#We're gonna use snakefood. It wraps ast and gets stuff we'd miss via dynamic imports.
#We have to modify depends.py to make it easier to parse the output.
def get_imports(infile):
	import_list = []
	if(os.name == 'nt'):
		cmd = "py279.exe %s %s" % (SFOOD_PATH,infile)
	else:
		cmd = "./py279 %s %s 2> /dev/null" % (SFOOD_PATH,infile)
 

	result = os.popen(cmd).read()
	result = result.split("\n")
	
	for rr in result:
		#Blank Line Detection.
		if re.match(r'^\s*$', rr):
			continue
		basemod,imp = rr.split("\t")
		DEPENDENCY_LIST[imp] = ""
		import_list.append(imp)
	return import_list

def get_bin_imports(indata):
	inlist = []
	indata = indata[indata.find("[Names]") + 8:indata.find("[Var Names]")]
	for d in indata.split("\n"):
		
		#Blank Line Detection.
		if re.match(r'^\s*$', d):
			continue
		d = d.strip()
		inlist.append(d[1:-1])
	
	return inlist
	
def disassemble_python(infile):
	cmd = "%s %s" % (CDAS_PATH,infile)
	return os.popen(cmd).read()
	
def decompile_python(infile):

	if sys.platform.startswith("win"):
		import ctypes
		SEM_NOGPFAULTERRORBOX = 0x0002 # From MSDN
		ctypes.windll.kernel32.SetErrorMode(SEM_NOGPFAULTERRORBOX);
		subprocess_flags = 0x8000000 #win32con.CREATE_NO_WINDOW?
	else:
		subprocess_flags = 0
		
	command = [CDC_PATH, infile]
	process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=subprocess_flags)
	(stdout, stderr) = process.communicate()
	return stdout
		
#Handle Binary Files.
def proc_bin(infile):
	infile = os.path.abspath(infile)
	print(infile)
	if(infile.endswith(".pyc")):
		file_type = ".pyc"
	if(infile.endswith(".pyd")):
		file_type = ".pyd"
	if(infile.endswith(".pyo")):
		file_type = ".pyo"

	file_disasm = disassemble_python(infile)
	#If uncompyle2 was able to decompile it already.
	if(os.path.exists("%s_dis" % infile)):
		uc = open("%s_dis" % infile,"rb")
		file_decomp = uc.read()
		uc.close()
	else:
		#We use the more compatible (but much less stable) pycdc.
		file_decomp = decompile_python(infile)

	f = open("tmp.py","wb")
	f.write(file_decomp)
	f.close()
	import_list = get_imports("tmp.py")
	os.remove("tmp.py")
	if(import_list == []):
		#Get imports the hacky way.
		get_bin_imports(file_disasm)
		
	
	MODULE_DB[infile] = {"import_list":import_list,"file_type":file_type,"file_disasm":file_disasm,"file_data":file_decomp}

#Process artifact.
def proc(infile):
	infile = os.path.abspath(infile)
	print(infile)
	#Handling Source Files.
	if(infile.endswith(".c") or infile.endswith(".cpp") or infile.endswith(".sh") or infile.endswith(".py") or infile.endswith(".html")):
		file_type = ".pm"
	else:
		#We short circuit and handle a binary file.
		proc_bin(infile)
	
	f = open(infile,"rb")
	file_data = f.read()
	f.close()
	import_list = get_imports(infile)
	MODULE_DB[infile] = {"import_list":import_list,"file_type":file_type,"file_data":file_data}

def usage():
	print("Usage: %s in_directory out_fpr optional_scan_pickle_file" % sys.argv[0])
	exit(1)

if(__name__=="__main__"):
	scanner_root = os.path.dirname(os.path.abspath(__file__))
	if(len(sys.argv) < 3 or len(sys.argv) > 4):
		usage()
	if(not os.path.exists(sys.argv[1])):
		usage()
	in_directory = os.path.abspath(sys.argv[1])
	out_fpr_directory = os.path.abspath(sys.argv[2])
	REPORT_PATH = out_fpr_directory
	if(not os.path.exists(out_fpr_directory)):
		os.makedirs(out_fpr_directory)
	saved_session_path = ""
	if(len(sys.argv) > 3):
		scanner_type	=sys.argv[3]
		#Add	the	type	selector	here	if	required
		#if(not os.path.exists(sys.argv[3])):
		#	print("Pickle File Not Found.")
		#	usage()
		#saved_session_path = sys.argv[3]
	print("PythonMCD Engine %s Started." % TOOL_VER)
	#Process All Files - Map Imports and get general info.
	#env_setup()
	pymcd_path = os.path.join(scanner_root)
	target_path = os.path.join(scanner_root,"input","python") #path of external python env
	#if(os.name == 'nt'):
	#	os.system("set PATH=%s;%s;%%PATH%%" % (target_path,pymcd_path))
	sys.path.insert(0,target_path)
	sys.path.insert(1,pymcd_path)

	if(saved_session_path == ""):
		print("Decompilation Engine 1 Running...")
		dcfiles = []
		for dirpath, dirnames, filenames in os.walk(in_directory):
			for filename in filenames:
				if(filename.endswith(".pyc") or filename.endswith(".pyd") or filename.endswith(".pyo")):
					#Ensure that we don't decompile anything twice.
					if(not os.path.exists(os.path.join(dirpath,"%s_dis" % filename))):
						#uncompyle hates bigger python files (especially big5 charsets) - we'll let pycdc do those.
						if(os.path.getsize(os.path.join(dirpath, filename)) > 80000):
							continue
						dcfiles.append(os.path.join(dirpath, filename))
						
		uncompyle6.main.main(".",".",dcfiles,[])
		print("Decompilation Engine 2 Running...")	
		for dirpath, dirnames, filenames in os.walk(in_directory):
			for filename in filenames:
				if(filename.endswith(".c") or filename.endswith(".cpp") or filename.endswith(".sh") or filename.endswith(".py") or filename.endswith(".html")):
					proc(os.path.join(dirpath, filename))
				if(filename.endswith(".pyc") or filename.endswith(".pyd") or filename.endswith(".pyo")):
					proc_bin(os.path.join(dirpath, filename))
		

		#TODO - Properly Process Dependencies more than one layer below (recursion)
		for dp in DEPENDENCY_LIST.keys():
			if(os.path.join(os.getcwd(),"Lib") in dp):
				continue
			if(dp.endswith(".pl" or ".pm")):
				proc(dp)
			if(dp.endswith(".pyc") or dp.endswith(".pyd") or dp.endswith(".pyo")):
				proc_bin(dp)

		#Save to Pickle file in case we want to re-find later.
		if(DBG_CACHING == True):
			print("Caching Results...")
			with open(os.path.join(saved_session_path,'scan_temp.cache'), 'wb') as handle:
				pickle.dump(MODULE_DB, handle)
			print("Caching Complete!")

	else:
		scan_cache = os.path.join(saved_session_path,'scan_temp.cache')
		
		if(not os.path.exists(scan_cache)):
			print("Error: %s not a cache file!" % scan_cache)
			exit(1)
		print("Loading Scan Cache: Please Wait...")
		with open(scan_cache, 'rb') as handle:
			MODULE_DB = b = pickle.load(s)
		print("Load Complete!")



	#Process all in MODULE_DB - Get Findings
	print("Discovering Elements...")
	proc_moduledb()
	
	#Process FINDINGS_DB - Get Patterns
	print("Discovering Patterns...")
	start_time = time.time()
	
	proc_findingsdb()
	#Print Report
	print("Printing Report...")
	
	gen_html_report(1)
	elapsed_time = time.time() - start_time
	print("Scan completed in %d Seconds." % elapsed_time)
	print("Done!")
