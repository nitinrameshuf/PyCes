import os
from os.path import join
from subprocess import Popen, PIPE
from workflows import analysis, Task

def mcd_robot_guard(context):
    if context['configuration'].MCD['enabled']:
        return Task.REQUIRED
    else:
        return Task.DISALLOWED

@analysis.guard(mcd_robot_guard)
@analysis.produces('RESULTS')
def mcd_robot(context):
    robot_dir = os.path.dirname(os.path.realpath(__file__))
    fvdl_dir = join(context['analysis_dir'], 'fvdls')

    analyze_java(context, robot_dir, fvdl_dir)
    analyze_dotnet(context, robot_dir,fvdl_dir)
    analyze_python(context, robot_dir,fvdl_dir)
	
def analyze_dotnet(context, robot_dir,fvdl_dir):
    script_path = join(robot_dir, 'analyze_dot_net')
    analysis_xq = context['configuration'].MCD['dot_net.analysis']
    priority_xq = context['configuration'].MCD['dot_net.priority']
    i = 0

    for binary_file in context['inventory']['DLLFile']:
        cur_path = join(binary_file._base_path, binary_file.path)
        results_path = join(fvdl_dir, 'mcd-dot_net-%d.fvdl' % i)
        i += 1
        p = Popen(['python', 'md2xml.py', cur_path,analysis_xq, priority_xq, results_path, context['analysis_dir'] + '/../source/'], stdin=PIPE, cwd=robot_dir)
        p.wait()

def analyze_python(context, robot_dir, fvdl_dir):
    script_path = join(robot_dir, 'analyze_python')
    base_path = os.path.abspath(os.path.join(context['submission_dir'],os.pardir))
    results_path = fvdl_dir
    p = Popen(['./py279','pymcd.py',base_path,results_path], stdin=PIPE, cwd=robot_dir)
	p.wait()

def analyze_java(context, robot_dir, fvdl_dir):
    script_path = join(robot_dir, 'analyze_java')
    analysis_xq = context['configuration'].MCD['java.analysis']
    priority_xq = context['configuration'].MCD['java.priority']
    results_path = join(fvdl_dir, 'mcd-java.fvdl')

    p = Popen([script_path, analysis_xq, priority_xq, results_path], stdin=PIPE, cwd=robot_dir)

    for class_file in context['inventory']['JavaBinaryFile']:
        p.stdin.write(join(class_file._base_path, class_file.path) + '\x00')

    p.stdin.close()
    p.wait()
